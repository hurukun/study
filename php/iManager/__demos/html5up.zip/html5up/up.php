<!DOCTYPE html>
<html>
<head>
    <title></title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"></head>
<body>
<style type="text/css">
#progress{ height:20px; border:1px solid #CCC; width:100px; display:none;}
#bar{ width:0; height:20px; background-color:#900;}
</style>
<form id="form1" enctype="multipart/form-data" method="post" action="uu.php">
    <div class="row">
      <label for="fileToUpload">Select a File to Upload</label><br />
      <input type="file" name="fileToUpload" id="fileToUpload" onChange="fileSelected();"/>
    </div>
    <div class="row">
      <input type="button" onClick="uploadFile()" value="Upload" />
    </div>
    <table width="310" border="0" cellspacing="0" cellpadding="0">
        <tr>
        <td width="100"> <div id="progress"><div id="bar"></div></div></td>
        <td><div id="b"></div></td>
        </tr>
    </table>
   
    <div id="fileName"></div>
    <div id="fileSize"></div>
    <div id="fileType"></div>    
    
</form>
<script type="text/javascript">

function fileSelected() {
	var file = document.getElementById('fileToUpload').files[0];
	if (file) {
		var fileSize = 0;
		if (file.size>1024 * 1024)
		  fileSize = (Math.round(file.size * 100 / (1024 * 1024)) / 100).toString() + 'MB';
		else
		  fileSize = (Math.round(file.size * 100 / 1024) / 100).toString() + 'KB';
			   
		document.getElementById('fileName').innerHTML = 'Name: ' + file.name;
		document.getElementById('fileSize').innerHTML = 'Size: ' + fileSize;
		document.getElementById('fileType').innerHTML = 'Type: ' + file.type;
	}
}
function uploadFile() {
	var xhr = new XMLHttpRequest();

	var fd = new FormData(document.getElementById('form1'));
	
	xhr.upload.addEventListener("progress", uploadProgress, false);

	xhr.addEventListener("load", uploadComplete, false); 
	xhr.addEventListener("error", uploadFailed, false); 
	xhr.addEventListener("abort", uploadCanceled, false);
	

	xhr.onreadystatechange = function(){
      if(xhr.readyState==4){
			if((xhr.status >= 200 && xhr.status < 300 ) || xhr.status == 304 ) //返回码两百内表示陈宫了 304表示告诉浏览器读缓存
         	var o  = eval("("+xhr.responseText+")");
			if(o.valid == 1){
				uploadComplete();
				alert("上传成功...");
			}
        }
	}

	xhr.open("POST", "upload.php"); 
	xhr.send(fd); 
}

function uploadProgress(e){
	var progress = document.getElementById("progress");
	progress.style.display = "block";
	var bar = document.getElementById("bar");
	var b   = document.getElementById("b");
	if(e.lengthComputable){
		var c = parseInt(((e.loaded)/(e.total))*10000)/10000;
		bar.style.width = parseInt(c*100)+"px";
		b.innerHTML = c*100+"%";
	}
}

function uploadComplete(e){
	document.getElementById("progress").style.display = "block";
	bar.style.width ="100px";
	b.innerHTML = "100% upadate ok";
}

function uploadFailed(){

}

function uploadCanceled(){

}
</script>
</body>
</html>