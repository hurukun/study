<?php
/*
print_r($_FILES);
Array
(
    [fileToUpload] => Array
        (
            [name] => demo.htm
            [type] => text/html
            [tmp_name] => C:\wamp\tmp\php4F1.tmp
            [error] => 0
            [size] => 29313
        )

)
*/

if ($_FILES["fileToUpload"]["error"] > 0)
{
	echo "{valid : 0 , message:'失败了'}" ;
}
else
{
    $is = move_uploaded_file($_FILES["fileToUpload"]["tmp_name"],"upload/" . $_FILES["fileToUpload"]["name"]);
	if($is){
		echo "{valid : 1 , message:'成功了'}" ;
	}else{
		echo "{valid : 0 , message:'上传成功 转移目录失败了 '}" ;
	}
}	
?>
